package com.cashmanager

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class PaiementchequeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_paiementcheque)
    }
}
